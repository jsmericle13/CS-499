
package com.gamingroom.auth;

import io.dropwizard.auth.AuthenticationException;
import io.dropwizard.auth.Authenticator;
import io.dropwizard.auth.basic.BasicCredentials;
import java.util.Optional;

public class GameAuthentinicator implements Authenticator<BasicCredentials, String> {
    @Override
    public Optional<String> authenticate(BasicCredentials credentials) throws AuthenticationException {
        if ("admin".equals(credentials.getUsername()) && "password".equals(credentials.getPassword())) {
            return Optional.of(credentials.getUsername());
        }
        return Optional.empty();
    }
}
