
package com.gamingroom.auth;

import io.dropwizard.auth.Authorizer;

public class GameAuthorizer implements Authorizer<String> {
    @Override
    public boolean authorize(String user, String role) {
        return "admin".equals(user) && "ADMIN".equals(role);
    }
}
